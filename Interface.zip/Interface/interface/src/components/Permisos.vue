<template>
  <v-layout align-start>
    <v-flex>
      <v-data-table :headers="headers" :items="permisos" :search="search" class="elevation-1">
        <template v-slot:top>
          <v-toolbar flat color="white">
            <v-toolbar-title>Permisos</v-toolbar-title>
            <v-divider class="mx-2" inset vertical></v-divider>
            <v-spacer></v-spacer>
            <v-text-field
              class="text-xs-center"
              v-model="search"
              append-icon="search"
              label="Búsqueda"
              single-line
              hide-details
            ></v-text-field>
            <v-spacer></v-spacer>
            <v-dialog v-model="dialog" max-width="500px">
              <template v-slot:activator="{ on }">
                <v-btn color="primary" dark class="mb-2" v-on="on">Nuevo permiso</v-btn>
              </template>
              <v-card>
                <v-card-title>
                  <span class="headline">Agregar</span>
                </v-card-title>
                <v-card-text>
                  <v-container grid-list-md>
                    <v-layout wrap>
                      <v-flex xs6 sm6 md6>
                        <v-text-field v-model="nombre_empleado" label="Nombre"></v-text-field>
                      </v-flex>
                      <v-flex xs6 sm6 md6>
                        <v-text-field v-model="apellidos_empleado" label="Apellido/s"></v-text-field>
                      </v-flex>
                      <v-flex xs6 sm6 md6>
                        <v-select v-model="id_tipo_permiso" :items="tipo_permisos" label="Permisos"></v-select>
                      </v-flex>
                      <v-flex xs12 sm12 md12>
                        <v-text-field type="date" v-model="fecha_permiso" label="Fecha"></v-text-field>
                      </v-flex>
                      <v-flex xs12 sm12 md12 v-show="valida">
                        <div class="red--text" v-for="v in validaMensaje" :key="v" v-text="v"></div>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-card-text>

                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="blue darken-1" text @click.native="close">Cerrar</v-btn>
                  <v-btn color="blue darken-1" text @click.native="guardar">Guardar</v-btn>
                </v-card-actions>
              </v-card>
            </v-dialog> 
          </v-toolbar>
        </template>
        <template v-slot:item.opciones="{ item }">
          <v-icon small class="mr-2" @click="deleteItem(item)">delete</v-icon>
        </template>
        <template v-slot:no-data>
          <v-btn outlined color="primary" @click="listar">Actualizar</v-btn>
        </template>
      </v-data-table>
    </v-flex>
  </v-layout>
</template>
<script>
import axios from "axios";
export default {
  data() {
    return {
      permisos: [],
      dialog: false,
      headers: [
        { text: "Nombre", value: "nombre_empleado" },
        { text: "Apellido", value: "apellidos_empleado" },
        { text: "Tipo", value: "tipo_permiso", sortable: false },
        { text: "Fecha", value: "fecha_permiso", sortable: false },
        { text: "Opciones", value: "opciones", sortable: false }
      ],
      search: "",
      id: "",
      id_tipo_permiso: "",
      tipo_permiso: "",
      tipo_permisos: [],
      nombre_empleado: "",
      apellidos_empleado: "",
      fecha_permiso: "",
      valida: 0,
      validaMensaje: []
    };
  },
  computed: {},

  watch: {
    dialog(val) {
      val || this.close();
    }
  },

  created() {
    this.listar();
    this.select();
  },
  methods: {
    listar() {
      let me = this;
      let header = { Authorization: "Bearer " + this.$store.state.token };
      let configuracion = { headers: header };
      axios
        .get("api/Permisos/Listar", configuracion)
        .then(function(response) {
          me.permisos = response.data;
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    select() {
      let me = this;
      let header = { Authorization: "Bearer " + this.$store.state.token };
      let configuracion = { headers: header };
      var tipo_permisosArray = [];
      axios
        .get("api/TipoPermisos/Listar", configuracion)
        .then(function(response) {
          tipo_permisosArray = response.data;
          tipo_permisosArray.map(function(x) {
            me.tipo_permisos.push({
              text: x.descripcion,
              value: x.id
            });
          });
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    deleteItem(item) {
      let me = this;
      let header = { Authorization: "Bearer " + this.$store.state.token };
      let configuracion = { headers: header };
      axios
        .delete("api/Permisos/Eliminar/" + item.id, configuracion)
        .then(function(response) {
          me.close();
          me.listar();
          me.limpiar();
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    close() {
      this.dialog = false;
      this.limpiar();
    },
    limpiar() {
      this.id = "";
      this.id_tipo_permiso = "";
      this.tipo_permisos = "";
      this.nombre_empleado = "";
      this.apellidos_empleado = "";
      this.fecha_permiso = "";
    },
    guardar() {
      if (this.validar()) {
        return;
      }
      let header = { Authorization: "Bearer " + this.$store.state.token };
      let configuracion = { headers: header };
      let me = this;
      axios
        .post(
          "api/Permisos/Crear",
          {
            id_tipo_permiso: me.id_tipo_permiso,
            nombre_empleado: me.nombre_empleado,
            apellidos_empleado: me.apellidos_empleado,
            fecha_permiso: me.fecha_permiso
          },
          configuracion
        )
        .then(function(response) {
          me.close();
          me.listar();
          me.limpiar();
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    validar() {
      this.valida = 0;
      this.validaMensaje = [];

      if (this.nombre_empleado.length <= 0 || this.nombre_empleado.length > 30) {
        this.validaMensaje.push("El nombre no puede ser vacío y permite hasta 30 caracteres.");
      }
      if (this.apellidos_empleado.length <= 0 || this.apellidos_empleado.length > 50) {
        this.validaMensaje.push("El apellido no puede ser vacío y permite hasta 50 caracteres.");
      }
      if (!this.id_tipo_permiso) {
        this.validaMensaje.push("Seleccione un tipo de permiso.");
      }
      if (!this.fecha_permiso) {
        this.validaMensaje.push("Seleccione una fecha válida.");
      }
      if (this.validaMensaje.length) {
        this.valida = 1;
      }
      return this.valida;
    }
  }
};
</script>