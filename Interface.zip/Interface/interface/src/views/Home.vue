<template>
  <v-layout wrap>
    <v-flex xs12 sm12 md12>
      <div>
        <Permisos></Permisos>
      </div>
    </v-flex>
  </v-layout>
</template>

<script>
// @ is an alias to /src
import Permisos from "@/components/Permisos.vue";

export default {
  name: "home",
  components: {
    Permisos
  }
};
</script>