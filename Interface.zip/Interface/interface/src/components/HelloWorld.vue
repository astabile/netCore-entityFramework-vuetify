<template>
  <v-container>
    <v-layout>
      <v-flex>
        <v-img :src="require('../assets/logo.svg')"></v-img>
      </v-flex>
    </v-layout>
  </v-container>
</template>